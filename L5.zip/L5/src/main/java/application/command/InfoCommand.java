package application.command;

public interface InfoCommand
{
}
